{
    let a = new Map();
    a.set('0',{
        bg_color: "green",
        simbol_color: "black",
        simbol: "*",
        move_into: [1,1,1,1],
        move_off:[1,1,1,1]
    });
    GLOBAL.DATA.SCENES_DATA[0].TILESETS.push({id: 0,content: a});
}