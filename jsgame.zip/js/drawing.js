let drawing = {};
drawing.drawGameSquare = function(x,y){}