function game(){
    let gameScene = {};
    //переменные и функции можно обьявлять тут, и они будут видны всем функциям ниже
    let setting = GLOBAL.DATA.SCENES_DATA[0];
    let currMap;
    gameScene.genMapObj = function(mapObj,tilesets){
        for(let i = 0;i < mapObj.content.length;i++){
            for(let j = o;j < mapObj.width;j++){
                getSimbolObj(mapObj.content[i]);
                i++;
            }
        }
    }
    gameScene.openMap = function(id){

    }
    gameScene.open = function(){

    };
    return gameScene;
}