function generateManager(){
    let manager = {};
    manager.SCENES = generateScenes(GLOBAL.DATA.scenesCount);
    manager.openScene = function(scene){
        SCENES[scene].open();
    };
    manager.openScene(GLOBAL.DATA.ENTRIE_SCENE);
    return manager;
}