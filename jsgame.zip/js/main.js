"use strict"
let GLOBAL = {};
GLOBAL.PLAYER = generatePlayer();
GLOBAL.MANAGER = generateManager();
GLOBAL.DATA = setup();