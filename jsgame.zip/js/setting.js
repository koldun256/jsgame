function setup(){
    let c = document.getElementById("canvas");

    return {
        SCENES_COUNT: 1,
        ENTRIE_SCENE: 0,
        CANVAS: c.getContext("2d"),
        WIDTH: c.width,
        HEIGHT: c.height,
        SCENES_DATA: [
            {
                SQARE_HEIGHT: 10,
                SQARE_WIDTH: 10,
                ENTRIE_MAP: 0,
                MAPS: [],
                TILESETS: []
            }
        ]
    };
}