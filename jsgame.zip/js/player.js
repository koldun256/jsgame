function generatePlayer(){    
    let player = {
        position: [0,0]
    };
    player.move = function(direction){
        switch (direction){
            case 0:
                break;
            case 1:
                break;
            case 2:
                break;
            case 3:
                break;
        }
        player.drawPlayer();
    };
    player.drawPlayer = function(){};
    return player;
}