function generateScenes(count){
    let scenes = [];
    function getScene(id){
        let scene = {};
        switch (id){
            case 0:
                //Далее - описание сцены(например - редактор карт, настройки, игра)
                //1-ый вариант:
                //scene.open = function(){};
                //scene.click = function(){};
                //Вариант 2: вынести описание сцены в отдельный файл
                //Например: scene = generateMapEditorScene()
                scene = game();
                break;
        }
        return scene;
    }
    for(let i = 0;i < count;i++){
        scenes.push(getScene(i));
    }
    return scenes;
}
